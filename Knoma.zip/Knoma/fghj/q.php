<!DOCTYPE html>
<html>
<head>
<title>Home</title>
</head>
<body>
<a href="home.php">Home</a><br>
Settings:<br>
<select name="settings">
  <option value="logout">Logout</option>
   <option value="update">change details</option>
</select> 
<br>
<a href="findpeople.php">Find People</a><br>
<a href="findpages.php">Find Pages</a><br>
<a href="following.php">Following</a><br>
<a href="followingpages">Pages</a><br>
<a href="followers.php">Followers</a><br>
Question:<textarea name="question" rows="2" cols="40"></textarea>

</body>
</html>