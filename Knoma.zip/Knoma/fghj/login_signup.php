

<!DOCTYPE html>
<html>
<head>
<title>Knoma</title>
</head>
<body>
<h2>Welcome to Knoma</h2>
Login
<form>
Email:<input type="email" name="email"><br>
Password:<input type="password" name="passwordd"><br>
<input type="submit" value="login">
</form>
<br>
Signup<br>
<form action="q/w.php" method="POST">
Name:<input type="text" name="name"><br>
Email:<input type="email" name="email"><br>
Password:<input type="password" name="passwordd"><br>
Username:<input type="text" name="username"><br>
Occupation:<input type="text" name="occupation"><br>
Phone Number:<input type="number" name="phone_number"><br>
Gender:<br>
<input type="radio" name="gender" value="male">Male<br>
<input type="radio" name="gender" value="female">Female<br>
<input type="radio" name="gender" value="others">Others<br>
Birthdate:<input type="date" name="birthdate"><br>
Age:<input type="number" name="age"><br>
<input type="submit" value="signup">
</form>
</body>
</html>