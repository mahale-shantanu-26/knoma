Copy the content of knoma.sql into a database named 'knoma' in phpMyAdmin.
Create a database named 'knoma' for that.
And store the 'Knoma' folder directly in 'htdocs', and not within any subfolder in htdocs